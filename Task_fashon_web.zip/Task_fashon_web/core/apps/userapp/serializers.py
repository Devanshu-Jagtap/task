from rest_framework import serializers
from .models import *
from apps.masteraap.models import *


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = "__all__"

# class CartItemSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CartItem
#         fields = "__all__"

class ProductLikeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Like
        fields = ['product_id'] 