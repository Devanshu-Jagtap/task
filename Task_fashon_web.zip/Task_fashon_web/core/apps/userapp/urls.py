from django.urls import path
from apps.userapp.views.userapp_view import *

urlpatterns = [
  
    path("",login ,name='login'),
    path("index",index ,name='index'),
]