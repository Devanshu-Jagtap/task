from rest_framework.views import APIView
from rest_framework.response import Response
from apps.masteraap.models import *
from apps.userapp.serializers import *
from apps.masteraap.util import *

class ProfileView(APIView):
    def post(self, request):
        data = request.data
        profile_image = data.get('profile_image')
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        middle_name = data.get('middle_name')
        phone_number_country_code = data.get('phone_number_country_code')
        phone_number = data.get('phone_number')
        home_address = data.get('home_address')

        if not all([profile_image, first_name, last_name, middle_name, phone_number_country_code, phone_number, home_address]):
            return error    ("All fields are required!")

        try:
            profile = Profile.objects.get(user_auth=request.user)
            return Response({'message': 'Profile already exists'}, status=status.HTTP_400_BAD_REQUEST)
        except Profile.DoesNotExist:
            serializer = ProfileSerializer(data=data)
            if serializer.is_valid():
                serializer.save(user_auth=request.user)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
# class AddToCartAPIView(APIView):
#     def post(self, request):
#         user = request.user
#         # Assuming the data contains product ID and quantity to add to the cart
#         serializer = CartItemSerializer(data=request.data)
#         if serializer.is_valid():
#             product_id = serializer.validated_data['product_id']
#             quantity = serializer.validated_data['quantity']
#             # Get or create the user's cart
#             cart, created = Cart.objects.get_or_create(user=user)
#             # Add item to the cart
#             cart_item, item_created = CartItem.objects.get_or_create(cart=cart, product_id=product_id)
#             if not item_created:
#                 cart_item.quantity += quantity
#             else:
#                 cart_item.quantity = quantity
#             cart_item.save()  # Save the cart item
#             return Response({'message': 'Item added to cart successfully'}, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LikeProductAPIView(APIView):
    def post(self, request):
        user = request.user
        serializer = ProductLikeSerializer(data=request.data)
        if serializer.is_valid():
            product_id = serializer.validated_data['product_id']
            # Check if the user has already liked the product
            if Like.objects.filter(user=user, product_id=product_id).exists():
                return Response({'message': 'You have already liked this product'}, status=status.HTTP_400_BAD_REQUEST)
            # Create a new like
            serializer.save(user=user)
            return Response({'message': 'Product liked successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)