from rest_framework import status

def success(self,msg,data=None):
    reponse = {
            'message':msg,
            'status':"success",
            'data':data,
            "code":status.HTTP_200_OK
    }
    return reponse

def error(self,msg):
    reponse={
            "message":msg,
            "status":"error",
            "code":status.HTTP_400_BAD_REQUEST
    }
    return reponse
    
def loginsuccess(self, msg,statuss):
    response = {
                    "message": msg,
                    "status" : "success",
                    "code"   : status.HTTP_200_OK,
                    "verify_status": statuss
                }
    return response

def loginerror(self, msg,statuss):
    response = {
                    "message": msg,
                    "status" : "failed",
                    "code"   : status.HTTP_400_BAD_REQUEST,
                    "verify_status": statuss
                }
    return response

