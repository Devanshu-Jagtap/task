from rest_framework import serializers
from .models import *

class CountrySerializer(serializers.ModelSerializer):
    class Meta:
        model = Country
        fields = '__all__'
        
class MainCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = MainCategory
        fields = ('id', 'CategoryName')

class SubCategorySerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=MainCategory.objects.all())
    class Meta:
        model = SubCategory
        fields = ['id', 'subcategoryname', 'category', 'category_id']

class SubSubCategorySerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=MainCategory.objects.all())
    subcategory = serializers.PrimaryKeyRelatedField(queryset=SubCategory.objects.all())

    class Meta:
        model = Sub_SubCategory
        fields = ['id', 'sub_subcategoryname', 'category', 'category_id', 'subcategory', 'subcategory_id']

class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brand
        fields = ['id', 'brandName', 'image']

class ProductSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=MainCategory.objects.all())
    subcategory = serializers.PrimaryKeyRelatedField(queryset=SubCategory.objects.all())
    sub_subcategory = serializers.PrimaryKeyRelatedField(queryset=Sub_SubCategory.objects.all())
    brand = serializers.PrimaryKeyRelatedField(queryset=Brand.objects.all())
    sizes_available = serializers.PrimaryKeyRelatedField(queryset=Size.objects.all(), many=True)
    color_available = serializers.PrimaryKeyRelatedField(queryset=Color.objects.all(), many=True)

    class Meta:
        model = Product
        fields = ['id', 'category', 'category_id', 'subcategory', 'subcategory_id',
                  'sub_subcategory', 'sub_subcategory_id', 'brand', 'productname',
                  'productprice', 'productdescription', 'sizes_available', 'color_available']
        
class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ['id', 'product', 'product_id', 'image']

class BlogCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = BlogCategory
        fields = ['id', 'blogcategory']

class BlogSerializer(serializers.ModelSerializer):
    blogcategory = serializers.PrimaryKeyRelatedField(queryset=BlogCategory.objects.all(), many=True)

    class Meta:
        model = Blog
        fields = ['id', 'blogcategory', 'blogname', 'blogcontent']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['days_since_posted'] = instance.days_since_posted()
        return data
    
class BlogImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = BlogImage
        fields = ['id', 'blog', 'blog_id', 'image']