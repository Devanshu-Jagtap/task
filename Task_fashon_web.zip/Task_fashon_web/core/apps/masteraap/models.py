from django.db import models
from apps.masteraap.basecontent import *
from apps.userapp.models import *
from django.utils import timezone


# Create your models here.
class MainCategory(BaseContent):
    CategoryName = models.CharField(max_length=255,unique=True)
    DisplayList = ['id','categoryName']
    searchable_fields = ['id','categoryName']
    class Meta:
        db_table ='masterapp_MainCategory'

    def __str__(self):
        return self.CategoryName
    
class SubCategory(BaseContent):
    subcategoryname = models.CharField(max_length=255,unique=True) 
    category = models.ForeignKey(to=MainCategory, on_delete=models.CASCADE)
    DisplayList = ['id','category','category_id',"subCategoryName"]
    searchable_fields = ['id','subCategoryName']
    class Meta:
        db_table ='masterapp_SubCategory'

    def __str__(self):
        return self.subcategoryname 
    
class Sub_SubCategory(BaseContent):
    sub_subcategoryname = models.CharField(max_length=255,unique=True)
    category = models.ForeignKey(to=MainCategory, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(to=SubCategory, on_delete=models.CASCADE)

    DisplayList = ['id','category','category_id',"subcategory","subcategory_id","sub_subcategoryName"]
    searchable_fields = ['id','sub_subcategoryName']
    class Meta:
        db_table ='masterapp_sub_subcategory'

    def __str__(self):
        return self.sub_subcategoryname

class Brand(BaseContent):
    brandName = models.CharField(max_length=255,unique=True)
    image = models.FileField(upload_to="images/")
    DisplayList = ['id','brand_name','image']
    searchable_fields = ['id','brand_name']
    class Meta:
        db_table ='masterapp_Brand'

    def __str__(self):
        return self.brandName
    
class Color(BaseContent):
    color = models.CharField(max_length=255,unique=True)
    color_image = models.FileField(upload_to="images/")
    DisplayList = ['id','color','color_image']
    searchable_fields = ['id','color']
    class Meta:
        db_table ='masterapp_Color'

    def __str__(self):
        return self.color

    
class Size(BaseContent):
    size = models.CharField(max_length=255,unique=True)
    DisplayList = ['id','size']
    searchable_fields = ['id','size']
    class Meta:
        db_table ='masterapp_Size'

    def __str__(self):
        return self.size


class Product(BaseContent):
    category = models.ForeignKey(to=MainCategory, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(to=SubCategory, on_delete=models.CASCADE)
    sub_subcategory = models.ForeignKey(to=Sub_SubCategory, on_delete=models.CASCADE) 
    brand = models.ForeignKey(to=Brand, on_delete=models.CASCADE)
    productname = models.CharField(max_length=255,unique=True)
    productprice = models.CharField(max_length=255,)
    productdescription = models.TextField()
    sizes_available = models.ManyToManyField(Size)
    color_available = models.ManyToManyField(Color)

    DisplayList = ['id','category','category_id',"subcategory","subcategory_id","sub_subcategory","sub_subcategory_id","brand","productname","productprice","productdescription","sizes_available","color_available"]
    searchable_fields = ['id','sub_subcategoryName']
    class Meta:
        db_table ='masterapp_Product'

    def __str__(self):
        return self.productname
    
class ProductImage(models.Model):
    product = models.ForeignKey(Product, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='product_images')
    DisplayList = ['id','product','product_id']
    searchable_fields = ['id','product'] 

    def __str__(self):
        return self.image


class BlogCategory(BaseContent):
    blogcategory = models.CharField(max_length=255,unique=True)
    DisplayList = ['id','blogcategory']
    searchable_fields = ['id','blogcategory']
    class Meta:
        db_table ='masterapp_BlogCategory'

    def __str__(self):
        return self.blogcategory
    
class Blog(BaseContent):
    blogcategory =  models.ManyToManyField(BlogCategory)
    blogname = models.CharField(max_length=255)
    blogcontent = models.TextField()
    DisplayList = ['id','blogcategory','blogcategory_id','blogcontent','blogname']
    searchable_fields = ['id','blogcontent','blogname']   
    def days_since_posted(self):
        return (timezone.now() - self.created_date).days
    
    def __str__(self):
        return self.blogname
    
class BlogImage(models.Model):
    blog = models.ForeignKey(Blog, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='blog_images')
    DisplayList = ['id','blog','blog_id']
    searchable_fields = ['id','blog'] 

    def __str__(self):
        return self.image

    
class Like(models.Model):
    user = models.ForeignKey(Tbl_User_Auth, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('user', 'product')

class Rating(models.Model):
    user = models.ForeignKey(Tbl_User_Auth, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=((1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')))
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'product')

class Country(BaseContent):
    country = models.CharField(max_length=100, unique=True)
    countryCode  = models.CharField(max_length=10)
    flag = models.FileField(upload_to='images/flag/',null=True)
    slug = models.SlugField(unique=True)

    DisplayList = ['id','country','countryCode','isActive']
    searchable_fields = ['id','country']
    class Meta:                 
        db_table ='masterapp_country'

    def __str__(self):
        return self.country 


