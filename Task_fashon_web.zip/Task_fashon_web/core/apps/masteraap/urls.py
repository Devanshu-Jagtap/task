from django.urls import path
from apps.masteraap.views.admin_view import *
from apps.masteraap.views.admin_api import *


urlpatterns = [
  

    path('country/',CountryView.as_view(), name='country'),
    path('country/<int:id>/', CountryView.as_view(), name='country'),

    path('category/',CategoryView.as_view(), name='category'),
    path('category/<int:id>/',CategoryView.as_view(), name='category'),

    path('subcategory/',SubcategoryView.as_view(), name='subcategory'),
    path('subcategory/<int:id>/',SubcategoryView.as_view(), name='subcategory'),

    path('sub_subsubcategory/',SubSubcategoryView.as_view(), name='sub_subcategory'),
    path('sub_subsubcategory/<int:id>/',SubSubcategoryView.as_view(), name='sub_subcategory'),

    path('brand/',BrandView.as_view(), name='brand'),
    path('brand/<int:id>/',BrandView.as_view(), name='brand'),

    path('color/',ColorView.as_view(), name='color'),
    path('color/<int:id>/',ColorView.as_view(), name='color'),

    path('size/',SizeView.as_view(), name='size'),
    path('size/<int:id>/',SizeView.as_view(), name='size'),

    path('product/',ProductView.as_view(), name='product'),
    path('product/<int:id>/',ProductView.as_view(), name='product'),

    path('blogcategory/',BlogCategoryView.as_view(), name='blogcategory'),
    path('blogcategory/<int:id>/',BlogCategoryView.as_view(), name='blogcategory'),

    path('blog/',BlogView.as_view(), name='blog'),
    path('blog/<int:id>/',BlogView.as_view(), name='blog'),

    ############################################API URL##############################################################
    path('api_country/', CountryListView.as_view(), name='api_country_list'),
    path('api_country/<int:pk>/', CountryListView.as_view(), name='api_country_detail'),

    path('api_main-category/', MainCategoryListView.as_view(), name='api_main_category_list'),
    path('api_main-category/<int:pk>/', MainCategoryListView.as_view(), name='api_main_category_detail'),

    path('api_sub-category/', SubCategoryListView.as_view(), name='api_sub_category_list'),
    path('api_sub-category/<int:pk>/', SubCategoryListView.as_view(), name='api_sub_category_detail'),

    path('api_sub-sub-category/', SubSubCategoryListView.as_view(), name='api_sub_sub_category_list'),
    path('api_sub-sub-category/<int:pk>/', SubSubCategoryListView.as_view(), name='api_sub_sub_category_detail'),

    path('api_brand/', BrandListView.as_view(), name='api_brand_list'),
    path('api_brand/<int:pk>/', BrandListView.as_view(), name='api_brand_detail'),

    path('api_product/', ProductListView.as_view(), name='api_product_list'),
    path('api_product/<int:id>/', ProductListView.as_view(), name='api_product_detail'),

    path('api_product-image/', ProductImageView.as_view(), name='api_product_image_list'),

    path('api_blog-category/', BlogCategoryListView.as_view(), name='api_blog_category_list'),
    path('api_blog-category/<int:id>/', BlogCategoryListView.as_view(), name='api_blog_category_detail'),

    path('api_blog/', BlogListView.as_view(), name='api_blog_list'),
    path('api_blog/<int:id>/', BlogListView.as_view(), name='api_blog_detail'),

    path('api_blog-image/', BlogImageView.as_view(), name='api_blog_image_list'),

]
   
