from django.shortcuts import render,redirect
# from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from apps.masteraap.models import *
from django.shortcuts import get_object_or_404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views import View
from django.db.models import Q


class CountryView(View):
    def get(self, request, id=None):
        if id:
            country = get_object_or_404(Country, pk=id)
            country.delete()
            messages.success(request, 'A Country is deleted successfully.')
            return redirect('/country')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                multiple_q = Q(Q(country__icontains=searchobj))
                data = Country.objects.filter(multiple_q)
            else:
                data = Country.objects.all()

            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                    data = paginator.page(page_number)
            except PageNotAnInteger:
                    data = paginator.page(1)
            except EmptyPage:
                    data = []

            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q")}
            else:
                context = {'data': data}

            return render(request, 'country.html',context  )

    def post(self, request, id=None):
   
        if id:
            country = get_object_or_404(Country, id=id)
            if 'status_update' in request.POST: 
                country.is_active = not country.is_active
                country.save()
                messages.success(request, 'A Country status updated successfully.')
                return redirect('/country')
            
            country_name = request.POST.get('country_name')
            country_code = request.POST.get('country_code')
            country_flag = request.FILES.get('country_flag')
            country_slug = request.POST.get('country_slug')

                    # Retrieve the existing country object from the database
            country = get_object_or_404(Country, pk=id)

                
            if (country.country != country_name or
                            country.countryCode   != country_code or
                            country.slug != country_slug or
                            country. flag != country_flag):

                        
                        country.country = country_name
                        country.countryCode   = country_code
                        country.slug = country_slug
                        country.flag = country_flag

                        
                        country.save()
                        messages.success(request, 'Country information updated successfully.')            
            return redirect('/country')

        else:
            country_name=request.POST['country_name']
            country_code=request.POST['country_code']
            country_flag=request.FILES.get('country_flag')
            country_slug=request.POST['country_slug']
            if Country.objects.filter(country=country_name,flag=country_flag).exists():
                    messages.error(request, 'A Country with same name already exists.')
                    return redirect('/country') 
            else:
                try:
                    country_master=Country(country=country_name,countryCode=country_code,flag=country_flag,slug=country_slug)
                    country_master.save()
                    messages.success(request, 'A Country Created Successfully..')
                except Exception as e:
                    messages.error(request, f'An error occurred slug be Unique')
            return redirect('/country')


class CategoryView(View):
    def get(self, request, id=None):
        if id:
            category = get_object_or_404(MainCategory, pk=id)
            category.delete()
            messages.success(request, 'A Category is deleted successfully.')
            return redirect('/category')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = MainCategory.objects.filter(name__icontains=searchobj)
            else:
                data = MainCategory.objects.all()

            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                data = paginator.page(page_number)
            except PageNotAnInteger:
                data = paginator.page(1)
            except EmptyPage:
                data = []

            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q")}
            else:
                context = {'data': data}

            return render(request, 'category.html', context)

    def post(self, request, id=None):
        if id:
            category = get_object_or_404(MainCategory, id=id)
            if 'status_update' in request.POST: 
                category.is_active = not category.is_active
                category.save()
                messages.success(request, 'A Category status updated successfully.')
                return redirect('/category')
            
            category_name = request.POST.get('category_name')
            category = get_object_or_404(MainCategory, id=id)
                
            if category.CategoryName != category_name:
                category.CategoryName = category_name
                category.save()
                messages.success(request, 'Category information updated successfully.')            
            return redirect('/category')

        else:
            category_name = request.POST.get('category_name')
            if MainCategory.objects.filter(CategoryName=category_name).exists():
                messages.error(request, 'A Category with the same name already exists.')
                return redirect('/category') 
            else:
                try:
                    category = MainCategory(CategoryName=category_name)
                    category.save()
                    messages.success(request, 'A Category Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the category.')
            return redirect('/category')

class SubcategoryView(View):
    def get(self, request, id=None):
        if id:
            subcategory = get_object_or_404(SubCategory, pk=id)
            subcategory.delete()
            messages.success(request, 'A Subcategory is deleted successfully.')
            return redirect('/subcategory')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = SubCategory.objects.filter(subCategoryName__icontains=searchobj)
            else:
                data = SubCategory.objects.all()

            # Pagination
            page_number = request.GET.get("page", 1)
            paginatorobj = Paginator(data, 10)
            try:
                data = paginatorobj.page(page_number)
            except PageNotAnInteger:
                data = paginatorobj.page(1)
            except EmptyPage:
                data = paginatorobj.page(paginatorobj.num_pages)

            maincatobj = MainCategory.objects.all()
            return render(request, 'sub_category.html', {'data': data, 'maincatobj':maincatobj})


    def post(self, request, id=None):
        if id:
            subcategory = get_object_or_404(SubCategory, pk=id)
            if 'status_update' in request.POST: 
                subcategory.is_active = not subcategory.is_active
                subcategory.save()
                messages.success(request, 'A Subcategory status updated successfully.')
                return redirect('/subcategory')
            
            subcategory_name = request.POST.get('subcategory_name')

            # Retrieve the existing subcategory object from the database
            subcategory = get_object_or_404(SubCategory, pk=id)
                
            if subcategory.subcategoryname != subcategory_name:
                subcategory.subcategoryname = subcategory_name
                subcategory.save()
                messages.success(request, 'Subcategory information updated successfully.')            
            return redirect('/subcategory')

        else:
            main_category_id = request.POST.get('category_id')
            main_category = get_object_or_404(MainCategory, pk=main_category_id)
            subcategory_name = request.POST['subcategory_name']
            if SubCategory.objects.filter(subcategoryname=subcategory_name, category=main_category).exists():
                messages.error(request, 'A Subcategory with the same name already exists for this main category.')
                return redirect('/subcategory') 
            else:
                try:
                    subcategory = SubCategory(subcategoryname=subcategory_name, category=main_category)
                    subcategory.save()
                    messages.success(request, 'A Subcategory Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the subcategory.')
            return redirect('/subcategory')
        
class SubSubcategoryView(View):
    def get(self, request, id=None):
        if id:
            sub_subcategory = get_object_or_404(Sub_SubCategory, pk=id)
            sub_subcategory.delete()
            messages.success(request, 'A Sub-Subcategory is deleted successfully.')
            return redirect('/sub_subcategory')
            
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = Sub_SubCategory.objects.filter(sub_subcategoryname__icontains=searchobj)
            else:
                data = Sub_SubCategory.objects.all()

            page_number = request.GET.get('page', 1)
            paginatorobj = Paginator(data, 10)
            try:
                data = paginatorobj.page(page_number)
            except PageNotAnInteger:
                data = paginatorobj.page(1)
            except EmptyPage:
                data = paginatorobj.page(paginatorobj.num_pages)


            maincatobj = MainCategory.objects.all()
            subcatobj = SubCategory.objects.all()
            return render(request, 'sub_subcategory.html', {'data': data, 'maincatobj': maincatobj, 'subcatobj': subcatobj})

    def post(self, request, id=None):
        if id:
            sub_subcategory = get_object_or_404(Sub_SubCategory, pk=id)
            if 'status_update' in request.POST: 
                sub_subcategory.is_active = not sub_subcategory.is_active
                sub_subcategory.save()
                messages.success(request, 'A Sub-Subcategory status updated successfully.')
                return redirect('/sub_subcategory')
            
            sub_subcategory_name = request.POST.get('sub_subcategory_name')

            # Retrieve the existing sub-subcategory object from the database
            sub_subcategory = get_object_or_404(Sub_SubCategory, pk=id)
                
            if sub_subcategory.sub_subcategoryname != sub_subcategory_name:
                sub_subcategory.sub_subcategoryname = sub_subcategory_name
                sub_subcategory.save()
                messages.success(request, 'Sub-Subcategory information updated successfully.')            
            return redirect('/sub_subcategory')

        else:
            category_id = request.POST.get('category_id')
            category = get_object_or_404(MainCategory, pk=category_id)
            subcategory_id = request.POST.get('subcategory_id')
            subcategory = get_object_or_404(SubCategory, pk=subcategory_id)
            sub_subcategory_name = request.POST['sub_subcategory_name']
            if Sub_SubCategory.objects.filter(sub_subcategoryname=sub_subcategory_name, category=category, subcategory=subcategory).exists():
                messages.error(request, 'A Sub-Subcategory with the same name already exists for this category and subcategory.')
                return redirect('/sub_subcategory') 
            else:
                try:
                    sub_subcategory = Sub_SubCategory(sub_subcategoryname=sub_subcategory_name, category=category, subcategory=subcategory)
                    sub_subcategory.save()
                    messages.success(request, 'A Sub-Subcategory Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the sub-subcategory.')
            return redirect('/sub_subcategory')

class BrandView(View):
    def get(self, request, id=None):
        if id:
            brand = get_object_or_404(Brand, pk=id)
            brand.delete()
            messages.success(request, 'A Brand is deleted successfully.')
            return redirect('/brand')
            
        else:
            data = Brand.objects.all()

            return render(request, 'brand.html', {'data': data})

    def post(self, request, id=None):
        if id:
            brand = get_object_or_404(Brand, pk=id)
            brand_name = request.POST.get('brand_name')
            brand_image = request.FILES.get('brand_image')

            if brand_name != brand.brandName or brand_image:
                brand.brandName = brand_name
                if brand_image:
                    brand.image = brand_image
                brand.save()
                messages.success(request, 'Brand information updated successfully.')            
            return redirect('/brand')

        else:
            brand_name = request.POST.get('brand_name')
            brand_image = request.FILES.get('brand_image')
            if Brand.objects.filter(brandName=brand_name).exists():
                messages.error(request, 'A Brand with the same name already exists.')
                return redirect('/brand') 
            else:
                try:
                    brand = Brand(brandName=brand_name, image=brand_image)
                    brand.save()
                    messages.success(request, 'A Brand Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the brand.')
            return redirect('/brand')
        
class ColorView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the color
            color = get_object_or_404(Color, pk=id)
            color.delete()
            messages.success(request, 'A Color is deleted successfully.')
            return redirect('/color')
        else:
            # If no ID is provided, it means we're displaying all colors
            colors = Color.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                colors = colors.filter(Q(color__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(colors, 5)  # Show 5 colors per page
            page_number = request.GET.get('page')
            try:
                colors = paginator.page(page_number)
            except PageNotAnInteger:
                colors = paginator.page(1)
            except EmptyPage:
                colors = paginator.page(paginator.num_pages)

            return render(request, 'colors.html', {'colors': colors})

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing color
            color = get_object_or_404(Color, pk=id)
            color_name = request.POST.get('color_name')
            color_image = request.FILES.get('color_image')

            # Update color information if the color name has changed or a new image is uploaded
            if color_name != color.color or color_image:
                color.color = color_name
                if color_image:
                    color.color_image = color_image
                color.save()
                messages.success(request, 'Color information updated successfully.')            
            return redirect('/color')
        else:
            # If no ID is provided, it means we're creating a new color
            color_name = request.POST['color_name']
            color_image = request.FILES.get('color_image')

            # Check if a color with the same name already exists
            if Color.objects.filter(color=color_name).exists():
                messages.error(request, 'A Color with the same name already exists.')
                return redirect('/color') 
            else:
                try:
                    # Create a new color with the provided name and image
                    color = Color(color=color_name, color_image=color_image)
                    color.save()
                    messages.success(request, 'A Color Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the color.')
            return redirect('/color')
        
class SizeView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the size
            size = get_object_or_404(Size, pk=id)
            size.delete()
            messages.success(request, 'A Size is deleted successfully.')
            return redirect('/size')
        else:
            # If no ID is provided, it means we're displaying all sizes
            sizes = Size.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                sizes = sizes.filter(Q(size__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(sizes, 5)  # Show 5 sizes per page
            page_number = request.GET.get('page')
            try:
                sizes = paginator.page(page_number)
            except PageNotAnInteger:
                sizes = paginator.page(1)
            except EmptyPage:
                sizes = paginator.page(paginator.num_pages)

            return render(request, 'size.html', {'sizes': sizes})

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing size
            size = get_object_or_404(Size, pk=id)
            size_name = request.POST.get('size_name')

            # Update size information if the size name has changed
            if size_name != size.size:
                size.size = size_name
                size.save()
                messages.success(request, 'Size information updated successfully.')            
            return redirect('/size')
        else:
            # If no ID is provided, it means we're creating a new size
            size_name = request.POST['size_name']

            # Check if a size with the same name already exists
            if Size.objects.filter(size=size_name).exists():
                messages.error(request, 'A Size with the same name already exists.')
                return redirect('/size') 
            else:
                try:
                    # Create a new size with the provided name
                    size = Size(size=size_name)
                    size.save()
                    messages.success(request, 'A Size Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the size.')
            return redirect('/size')
class ProductView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the product
            product = get_object_or_404(Product, pk=id)
            product.delete()
            messages.success(request, 'A Product is deleted successfully.')
            return redirect('/product')
        else:
            # If no ID is provided, it means we're displaying all products
            products = Product.objects.all()
            productimg = ProductImage.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                products = products.filter(Q(productname__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(products, 5)  # Show 5 products per page
            page_number = request.GET.get('page')
            try:
                products = paginator.page(page_number)
            except PageNotAnInteger:
                products = paginator.page(1)
            except EmptyPage:
                products = paginator.page(paginator.num_pages)

            mainobj = MainCategory.objects.all()
            subobj = SubCategory.objects.all()
            subsubobj = Sub_SubCategory.objects.all()
            brandobj = Brand.objects.all()
            sizeobj = Size.objects.all()
            colorobj = Color.objects.all()

            context = {
                'products': products,
                "mainobj": mainobj,
                "subobj": subobj,
                "subsubobj": subsubobj,
                "brandobj": brandobj,
                'sizeobj': sizeobj,
                'colorobj': colorobj,
                'productimg': productimg
            }

            return render(request, 'product.html', context)

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing product
            product = get_object_or_404(Product, pk=id)
            product_name = request.POST.get('product_name')
            product_price = request.POST.get('product_price')
            product_description = request.POST.get('product_description')

            # Update product information
            product.productname = product_name
            product.productprice = product_price
            product.productdescription = product_description
            product.save()

            # Handle Many-to-Many fields: sizes_available and color_available
            sizes_available = request.POST.getlist('sizes_available')
            colors_available = request.POST.getlist('colors_available')
            product.sizes_available.set(sizes_available)
            product.color_available.set(colors_available)

            # Handle Product Images
            images = request.FILES.getlist('product_images')
            for image in images:
                ProductImage.objects.create(product=product, image=image)

            messages.success(request, 'Product information updated successfully.')
            return redirect('/product')
        else:
            try:
                # Retrieve form data
                category_id = request.POST.get('category')
                subcategory_id = request.POST.get('subcategory')
                sub_subcategory_id = request.POST.get('sub_subcategory')
                brand_id = request.POST.get('brand')
                product_name = request.POST.get('product_name')
                product_price = request.POST.get('product_price')
                product_description = request.POST.get('product_description')
                sizes_available_ids = request.POST.getlist('sizes_available')
                colors_available_ids = request.POST.getlist('colors_available')
                images = request.FILES.getlist('product_images')

                # Check if a product with the same name already exists
                if Product.objects.filter(productname=product_name).exists():
                    messages.error(request, 'A Product with the same name already exists.')
                    return redirect('/product')

                # Convert category, subcategory, sub_subcategory, and brand IDs to instances
                category = MainCategory.objects.get(pk=category_id)
                subcategory = SubCategory.objects.get(pk=subcategory_id)
                sub_subcategory = Sub_SubCategory.objects.get(pk=sub_subcategory_id)
                brand = Brand.objects.get(pk=brand_id)

                # Create a new product
                product = Product(
                    category=category,
                    subcategory=subcategory,
                    sub_subcategory=sub_subcategory,
                    brand=brand,
                    productname=product_name,
                    productprice=product_price,
                    productdescription=product_description
                )
                product.save()

                # Handle Many-to-Many fields: sizes_available and color_available
                product.sizes_available.set(sizes_available_ids)
                product.color_available.set(colors_available_ids)

                # Handle Product Images
                for image in images:
                    ProductImage.objects.create(product=product, image=image)

                messages.success(request, 'A Product Created Successfully.')
            except Exception as e:
                print(f"Error occurred: {e}")
                messages.error(request, 'An error occurred while creating the product.')

            return redirect('/product')
        
class BlogCategoryView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the blog category
            blog_category = get_object_or_404(BlogCategory, pk=id)
            blog_category.delete()
            messages.success(request, 'A Blog Category is deleted successfully.')
            return redirect('/blogcategory')
        else:
            # If no ID is provided, it means we're displaying all blog categories
            blog_categories = BlogCategory.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                blog_categories = blog_categories.filter(Q(blogcategory__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(blog_categories, 5)  # Show 5 blog categories per page
            page_number = request.GET.get('page')
            try:
                blog_categories = paginator.page(page_number)
            except PageNotAnInteger:
                blog_categories = paginator.page(1)
            except EmptyPage:
                blog_categories = paginator.page(paginator.num_pages)

            return render(request, 'blogcategory.html', {'blog_categories': blog_categories})

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing blog category
            blog_category = get_object_or_404(BlogCategory, pk=id)
            blog_category_name = request.POST.get('blog_category_name')

            # Update blog category information if the blog category name has changed
            if blog_category_name != blog_category.blogcategory:
                blog_category.blogcategory = blog_category_name
                blog_category.save()
                messages.success(request, 'Blog Category information updated successfully.')            
            return redirect('/blog_category')
        else:
            # If no ID is provided, it means we're creating a new blog category
            blog_category_name = request.POST['blog_category_name']

            # Check if a blog category with the same name already exists
            if BlogCategory.objects.filter(blogcategory=blog_category_name).exists():
                messages.error(request, 'A Blog Category with the same name already exists.')
                return redirect('/blogcategory') 
            else:
                try:
                    # Create a new blog category with the provided name
                    blog_category = BlogCategory(blogcategory=blog_category_name)
                    blog_category.save()
                    messages.success(request, 'A Blog Category Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the blog category.')
            return redirect('/blogcategory')
        
class BlogView(View):
    def get(self, request, id=None):
        if id:
            # If an ID is provided, it means we're deleting the blog
            blog = get_object_or_404(Blog, pk=id)
            blog.delete()
            messages.success(request, 'A Blog is deleted successfully.')
            return redirect('/blog')
        else:
            # If no ID is provided, it means we're displaying all blogs
            blogs = Blog.objects.all()

            # Implementing search functionality
            search_query = request.GET.get('q')
            if search_query:
                blogs = blogs.filter(Q(blogname__icontains=search_query) | Q(blogcontent__icontains=search_query))

            # Implementing pagination
            paginator = Paginator(blogs, 5)  # Show 5 blogs per page
            page_number = request.GET.get('page')
            try:
                blogs = paginator.page(page_number)
            except PageNotAnInteger:
                blogs = paginator.page(1)
            except EmptyPage:
                blogs = paginator.page(paginator.num_pages)
            blog_categoriesobj = BlogCategory.objects.all()
                
            context={'blogs': blogs , 'blog_categoriesobj':blog_categoriesobj }

            return render(request, 'blog.html', context)

    def post(self, request, id=None):
        if id:
            # If an ID is provided, it means we're updating an existing blog
            blog = get_object_or_404(Blog, pk=id)
            blog_name = request.POST.get('blog_name')
            blog_content = request.POST.get('blog_content')
            blog_categories_ids = request.POST.getlist('blog_categories')

            # Update blog information
            blog.blogname = blog_name
            blog.blogcontent = blog_content
            blog.save()

            # Handle Many-to-Many field: blogcategory
            blog.blogcategory.set(blog_categories_ids)

            messages.success(request, 'Blog information updated successfully.')
            return redirect('/blog')
        else:
            # If no ID is provided, it means we're creating a new blog
            blog_name = request.POST.get('blog_name')
            blog_content = request.POST.get('blog_content')
            blog_categories_ids = request.POST.getlist('blog_categories')
            blog_images = request.FILES.getlist('blog_images')

            # Check if a blog with the same name already exists
            if Blog.objects.filter(blogname=blog_name).exists():
                messages.error(request, 'A Blog with the same name already exists.')
                return redirect('/blog')
                
            else:
                try:
                    # Create a new blog
                    blog = Blog(blogname=blog_name, blogcontent=blog_content)
                    blog.save()

                    # Handle Many-to-Many field: blogcategory
                    blog.blogcategory.set(blog_categories_ids)
                    for image in blog_images:
                        BlogImage.objects.create(blog=blog, image=image)

                    messages.success(request, 'A Blog Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the blog.')

            return redirect('/blog')