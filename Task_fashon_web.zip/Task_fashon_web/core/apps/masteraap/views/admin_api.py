import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from apps.masteraap.models import *
from apps.masteraap.serializers import *
from apps.masteraap.util import *

logger = logging.getLogger(__name__)

class CountryListView(APIView):
    def get(self, request):
        try:
            countries = Country.objects.all()
            serializer = CountrySerializer(countries,many=True)
            return Response(success(self,data=serializer.data, msg='success'))
        except Exception as e:
            logger.error(f"Error in CountryListView: {str(e)}")

            return Response(error(self,msg='Error'))
        
class MainCategoryListView(APIView):
    def get(self, request):
        try:
            categories = MainCategory.objects.all()
            serializer = MainCategorySerializer(categories, many=True)
            return Response(success(self,data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self,msg='Error'))

class SubCategoryListView(APIView):
    def get(self, request):
        try:
            subcategories = SubCategory.objects.all()
            serializer = SubCategorySerializer(subcategories, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))

class SubSubCategoryListView(APIView):
    def get(self, request):
        try:
            sub_subcategories = Sub_SubCategory.objects.all()
            serializer = SubSubCategorySerializer(sub_subcategories, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))
        
class BrandListView(APIView):
    def get(self, request):
        try:
            brands = Brand.objects.all()
            serializer = BrandSerializer(brands, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))
        
class ProductListView(APIView):
    def get(self, request, id=None,subcategory_id=None):
        try:
            if id:
                product = Product.objects.get(id=id)
                serializer = ProductSerializer(product)
                return Response(success(self, data=serializer.data, msg='success'))
            elif subcategory_id:
                products = Product.objects.filter(subcategory=subcategory_id)
                serializer = ProductSerializer(products, many=True)
                return Response(success(self, data=serializer.data, msg='success'))
            else:
                products = Product.objects.all()
                serializer = ProductSerializer(products, many=True)
                return Response(success(self, data=serializer.data, msg='success'))
        except Product.DoesNotExist:
            return Response(error(self, msg='Product not found'), status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(error(self, msg='Error'))
        
class ProductImageView(APIView):
    def get(self, request):
        try:
            product_images = ProductImage.objects.all()
            serializer = ProductImageSerializer(product_images, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))
        
class BlogCategoryListView(APIView):
    def get(self, request):
        try:
            blog_categories = BlogCategory.objects.all()
            serializer = BlogCategorySerializer(blog_categories, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))
        
class BlogListView(APIView):
    def get(self, request, id=None):
        try:
            if id:
                blog = Blog.objects.get(id=id)
                serializer = BlogSerializer(blog)
                return Response(success(self, data=serializer.data, msg='success'))
            else:
                blogs = Blog.objects.all()
                serializer = BlogSerializer(blogs, many=True)
                return Response(success(self, data=serializer.data, msg='success'))
        except Blog.DoesNotExist:
            return Response(error(self, msg='Blog not found'), status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response(error(self, msg='Error'))

class BlogImageView(APIView):
    def get(self, request):
        try:
            blog_images = BlogImage.objects.all()
            serializer = BlogImageSerializer(blog_images, many=True)
            return Response(success(self, data=serializer.data, msg='success'))
        except Exception as e:
            return Response(error(self, msg='Error'))