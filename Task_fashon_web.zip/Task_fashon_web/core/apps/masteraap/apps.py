from django.apps import AppConfig


class MasteraapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.masteraap'
